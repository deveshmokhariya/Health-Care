import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/doctor/')({
  component: DoctorPortal,
})

function DoctorPortal() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <div className="max-w-2xl w-full text-center">
        <div className="w-20 h-20 bg-green-100 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-6">
          👨‍⚕️
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-3">Doctor Portal</h1>
        <p className="text-gray-500 mb-8">
          View your schedule, read patient symptom forms, write visit notes, and manage prescriptions.
        </p>
        <div className="grid grid-cols-2 gap-4 text-left">
          {['My Schedule', 'Patient Forms', 'Write Visit Notes', 'Prescriptions'].map((item) => (
            <div key={item} className="rounded-xl border border-dashed border-green-300 bg-green-50 p-4">
              <p className="text-sm font-medium text-green-600">{item}</p>
              <p className="text-xs text-green-400 mt-1">Coming in a future step</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
