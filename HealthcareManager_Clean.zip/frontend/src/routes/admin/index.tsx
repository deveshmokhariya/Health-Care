import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/admin/')({
  component: AdminPortal,
})

function AdminPortal() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <div className="max-w-2xl w-full text-center">
        <div className="w-20 h-20 bg-purple-100 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-6">
          ⚙️
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-3">Admin Portal</h1>
        <p className="text-gray-500 mb-8">
          Manage doctor profiles, working hours, leave schedules, and review leave conflicts.
        </p>
        <div className="grid grid-cols-2 gap-4 text-left">
          {['Doctor List', 'Add Doctor', 'Leave Calendar', 'Leave Conflicts'].map((item) => (
            <div key={item} className="rounded-xl border border-dashed border-purple-300 bg-purple-50 p-4">
              <p className="text-sm font-medium text-purple-600">{item}</p>
              <p className="text-xs text-purple-400 mt-1">Building in Step 2</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
