import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/patient/')({
  component: PatientPortal,
})

function PatientPortal() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <div className="max-w-2xl w-full text-center">
        <div className="w-20 h-20 bg-blue-100 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-6">
          🏥
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-3">Patient Portal</h1>
        <p className="text-gray-500 mb-8">
          Book appointments, fill symptom forms, view prescriptions, and track your health.
        </p>
        <div className="grid grid-cols-2 gap-4 text-left">
          {['Search Doctors', 'Book Appointment', 'My Appointments', 'Prescriptions'].map((item) => (
            <div key={item} className="rounded-xl border border-dashed border-blue-300 bg-blue-50 p-4">
              <p className="text-sm font-medium text-blue-600">{item}</p>
              <p className="text-xs text-blue-400 mt-1">Coming in next step</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
