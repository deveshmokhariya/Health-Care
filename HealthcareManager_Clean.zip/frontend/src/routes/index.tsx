import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/')({
  component: LandingPage,
})

function LandingPage() {
  const portals = [
    {
      title: 'Patient Portal',
      href: '/patient',
      description: 'Book appointments, view records, and manage prescriptions.',
      color: 'bg-blue-500',
      icon: '🏥',
    },
    {
      title: 'Doctor Portal',
      href: '/doctor',
      description: 'Manage your schedule, view patient forms, and write notes.',
      color: 'bg-green-500',
      icon: '👨‍⚕️',
    },
    {
      title: 'Admin Portal',
      href: '/admin',
      description: 'Manage doctors, leaves, system config, and reports.',
      color: 'bg-purple-500',
      icon: '⚙️',
    },
  ]

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <h1 className="text-4xl font-bold text-gray-800 mb-2">Healthcare Manager</h1>
      <p className="text-gray-500 mb-12 text-lg">Select your portal to continue</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
        {portals.map((portal) => (
          <Link
            key={portal.href}
            to={portal.href}
            className="group block rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className={`w-12 h-12 ${portal.color} rounded-xl flex items-center justify-center text-2xl mb-4`}>
              {portal.icon}
            </div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-blue-600 transition-colors">
              {portal.title}
            </h2>
            <p className="text-gray-500 text-sm">{portal.description}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
