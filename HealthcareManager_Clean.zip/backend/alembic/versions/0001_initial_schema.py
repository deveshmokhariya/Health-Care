"""Initial schema — all tables

Revision ID: 0001
Revises: 
Create Date: 2026-08-23
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- Enums ---
    userrole = postgresql.ENUM('patient', 'doctor', 'admin', name='userrole')
    userrole.create(op.get_bind())

    appointmentstatus = postgresql.ENUM('pending', 'confirmed', 'cancelled', 'completed', name='appointmentstatus')
    appointmentstatus.create(op.get_bind())

    urgencylevel = postgresql.ENUM('low', 'medium', 'high', 'critical', name='urgencylevel')
    urgencylevel.create(op.get_bind())

    notificationtype = postgresql.ENUM(
        'booking_confirmation', 'reminder', 'cancellation', 'leave_alert', 'leave_conflict', 'llm_summary',
        name='notificationtype'
    )
    notificationtype.create(op.get_bind())

    notificationchannel = postgresql.ENUM('email', 'sms', 'push', name='notificationchannel')
    notificationchannel.create(op.get_bind())

    notificationstatus = postgresql.ENUM('pending', 'sent', 'failed', name='notificationstatus')
    notificationstatus.create(op.get_bind())

    calendarsyncstatus = postgresql.ENUM('pending', 'synced', 'failed', name='calendarsyncstatus')
    calendarsyncstatus.create(op.get_bind())

    # --- users ---
    op.create_table(
        'users',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('hashed_password', sa.String, nullable=False),
        sa.Column('role', sa.Enum('patient', 'doctor', 'admin', name='userrole'), nullable=False),
        sa.Column('full_name', sa.String(255), nullable=False),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index('ix_users_email', 'users', ['email'], unique=True)

    # --- doctor_profiles ---
    op.create_table(
        'doctor_profiles',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('specialisation', sa.String(100), nullable=False),
        sa.Column('qualification', sa.Text, nullable=True),
        sa.Column('bio', sa.Text, nullable=True),
        sa.Column('slot_duration_minutes', sa.Integer, nullable=False, server_default='30'),
        sa.Column('working_hours_start', sa.Time, nullable=False),
        sa.Column('working_hours_end', sa.Time, nullable=False),
        sa.Column('working_days', postgresql.ARRAY(sa.Integer), nullable=False),
        sa.Column('max_advance_days', sa.Integer, nullable=False, server_default='30'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index('ix_doctor_profiles_user_id', 'doctor_profiles', ['user_id'], unique=True)
    op.create_index('ix_doctor_profiles_specialisation', 'doctor_profiles', ['specialisation'])

    # --- doctor_leaves ---
    op.create_table(
        'doctor_leaves',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('doctor_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('leave_date', sa.Date, nullable=False),
        sa.Column('reason', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint('doctor_id', 'leave_date', name='uq_doctor_leaves_doctor_date'),
    )
    op.create_index('ix_doctor_leaves_doctor_date', 'doctor_leaves', ['doctor_id', 'leave_date'])

    # --- appointments ---
    op.create_table(
        'appointments',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('doctor_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('slot_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('slot_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('status', sa.Enum('pending', 'confirmed', 'cancelled', 'completed', name='appointmentstatus'), nullable=False, server_default='pending'),
        sa.Column('cancellation_reason', sa.Text, nullable=True),
        sa.Column('cancelled_by', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        # Anti-double-booking constraint
        sa.UniqueConstraint('doctor_id', 'slot_start', name='uq_appointments_doctor_slot'),
        sa.CheckConstraint('slot_end > slot_start', name='ck_appointments_slot_end_after_start'),
        sa.CheckConstraint('patient_id != doctor_id', name='ck_appointments_patient_ne_doctor'),
    )
    op.create_index('ix_appointments_patient_id', 'appointments', ['patient_id'])
    op.create_index('ix_appointments_doctor_id', 'appointments', ['doctor_id'])
    op.create_index('ix_appointments_status', 'appointments', ['status'])

    # --- symptom_forms ---
    op.create_table(
        'symptom_forms',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('appointment_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('appointments.id', ondelete='CASCADE'), nullable=False, unique=True),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('symptoms', sa.Text, nullable=False),
        sa.Column('duration_days', sa.Integer, nullable=True),
        sa.Column('severity', sa.Integer, nullable=True),
        sa.Column('llm_urgency_level', sa.Enum('low', 'medium', 'high', 'critical', name='urgencylevel'), nullable=True),
        sa.Column('llm_summary', sa.Text, nullable=True),
        sa.Column('submitted_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint('severity BETWEEN 1 AND 10', name='ck_symptom_forms_severity_range'),
    )
    op.create_index('ix_symptom_forms_patient_id', 'symptom_forms', ['patient_id'])

    # --- visit_notes ---
    op.create_table(
        'visit_notes',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('appointment_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('appointments.id', ondelete='CASCADE'), nullable=False, unique=True),
        sa.Column('doctor_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('raw_notes', sa.Text, nullable=False),
        sa.Column('llm_patient_summary', sa.Text, nullable=True),
        sa.Column('llm_medication_schedule', postgresql.JSONB, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index('ix_visit_notes_doctor_id', 'visit_notes', ['doctor_id'])

    # --- prescriptions ---
    op.create_table(
        'prescriptions',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('visit_note_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('visit_notes.id', ondelete='CASCADE'), nullable=False),
        sa.Column('appointment_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('appointments.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('medication_name', sa.String(255), nullable=False),
        sa.Column('dosage', sa.String(100), nullable=True),
        sa.Column('frequency', sa.String(100), nullable=True),
        sa.Column('duration_days', sa.Integer, nullable=True),
        sa.Column('instructions', sa.Text, nullable=True),
        sa.Column('reminder_enabled', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index('ix_prescriptions_patient_id', 'prescriptions', ['patient_id'])
    op.create_index('ix_prescriptions_visit_note_id', 'prescriptions', ['visit_note_id'])

    # --- notifications ---
    op.create_table(
        'notifications',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('appointment_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('appointments.id', ondelete='SET NULL'), nullable=True),
        sa.Column('type', sa.Enum('booking_confirmation', 'reminder', 'cancellation', 'leave_alert', 'leave_conflict', 'llm_summary', name='notificationtype'), nullable=False),
        sa.Column('channel', sa.Enum('email', 'sms', 'push', name='notificationchannel'), nullable=False, server_default='email'),
        sa.Column('subject', sa.String(255), nullable=True),
        sa.Column('body', sa.Text, nullable=False),
        sa.Column('status', sa.Enum('pending', 'sent', 'failed', name='notificationstatus'), nullable=False, server_default='pending'),
        sa.Column('retry_count', sa.Integer, nullable=False, server_default='0'),
        sa.Column('max_retries', sa.Integer, nullable=False, server_default='3'),
        sa.Column('scheduled_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('sent_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index('ix_notifications_user_id', 'notifications', ['user_id'])
    op.create_index('ix_notifications_appointment_id', 'notifications', ['appointment_id'])
    op.create_index('ix_notifications_status', 'notifications', ['status'])

    # --- calendar_events ---
    op.create_table(
        'calendar_events',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), primary_key=True),
        sa.Column('appointment_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('appointments.id', ondelete='CASCADE'), nullable=False, unique=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('google_event_id', sa.String(255), nullable=True),
        sa.Column('google_calendar_id', sa.String(255), nullable=True),
        sa.Column('sync_status', sa.Enum('pending', 'synced', 'failed', name='calendarsyncstatus'), nullable=False, server_default='pending'),
        sa.Column('last_synced_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index('ix_calendar_events_user_id', 'calendar_events', ['user_id'])


def downgrade() -> None:
    op.drop_table('calendar_events')
    op.drop_table('notifications')
    op.drop_table('prescriptions')
    op.drop_table('visit_notes')
    op.drop_table('symptom_forms')
    op.drop_table('appointments')
    op.drop_table('doctor_leaves')
    op.drop_table('doctor_profiles')
    op.drop_table('users')

    for enum_name in [
        'userrole', 'appointmentstatus', 'urgencylevel',
        'notificationtype', 'notificationchannel', 'notificationstatus', 'calendarsyncstatus',
    ]:
        op.execute(f'DROP TYPE IF EXISTS {enum_name}')
